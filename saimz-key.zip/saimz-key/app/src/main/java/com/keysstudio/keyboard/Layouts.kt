package com.keysstudio.keyboard

enum class KeyType { CHAR, SHIFT, DELETE, SYMBOLS, LETTERS, MORE_SYMBOLS, EMOJI, SPACE, ENTER }

enum class Mode { LETTERS, SYM1, SYM2 }

class Key(
    val label: String,
    val type: KeyType = KeyType.CHAR,
    val weight: Float = 1f,
    val output: String = label
)

/** [indent] is the empty space on each side of the row, in key widths. */
class Row(val keys: List<Key>, val indent: Float = 0f)

object Layouts {

    private fun chars(s: String): List<Key> = s.map { Key(it.toString()) }

    private fun bottomRow(switchLabel: String, switchType: KeyType): Row = Row(
        listOf(
            Key(switchLabel, switchType, 1.4f),
            Key(",", KeyType.CHAR, 1f),
            Key("☺", KeyType.EMOJI, 1.1f),
            Key(" ", KeyType.SPACE, 4f),
            Key(".", KeyType.CHAR, 1f),
            Key("↵", KeyType.ENTER, 1.5f)
        )
    )

    fun rows(mode: Mode, numberRow: Boolean): List<Row> {
        val out = ArrayList<Row>()
        when (mode) {
            Mode.LETTERS -> {
                if (numberRow) out.add(Row(chars("1234567890")))
                out.add(Row(chars("qwertyuiop")))
                out.add(Row(chars("asdfghjkl"), 0.5f))
                out.add(
                    Row(
                        listOf(Key("⇧", KeyType.SHIFT, 1.5f)) +
                            chars("zxcvbnm") +
                            Key("⌫", KeyType.DELETE, 1.5f)
                    )
                )
                out.add(bottomRow("?123", KeyType.SYMBOLS))
            }

            Mode.SYM1 -> {
                out.add(Row(chars("1234567890")))
                out.add(Row(chars("@#\$%&-+()/")))
                out.add(
                    Row(
                        listOf(Key("1/2", KeyType.MORE_SYMBOLS, 1.5f)) +
                            chars("*\"':;!?") +
                            Key("⌫", KeyType.DELETE, 1.5f)
                    )
                )
                out.add(bottomRow("ABC", KeyType.LETTERS))
            }

            Mode.SYM2 -> {
                out.add(Row(chars("~`|•√π÷×¶∆")))
                out.add(Row(chars("£€¥¢^°={}\\")))
                out.add(
                    Row(
                        listOf(Key("2/2", KeyType.MORE_SYMBOLS, 1.5f)) +
                            chars("[]<>©®™") +
                            Key("⌫", KeyType.DELETE, 1.5f)
                    )
                )
                out.add(bottomRow("ABC", KeyType.LETTERS))
            }
        }
        return out
    }
}
