package com.keysstudio.keyboard

import android.content.Context
import android.graphics.drawable.GradientDrawable
import android.text.TextUtils
import android.view.Gravity
import android.widget.GridLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

/** Emoji grid plus a "stickers" tab of text stickers the user edits in settings. */
class EmojiPanel(context: Context, private val prefs: Prefs) : LinearLayout(context) {

    interface Listener {
        fun onInsert(text: String)
        fun onBack()
        fun onDelete()
    }

    var listener: Listener? = null

    private val tabLabels = listOf("😀", "🐶", "🍔", "⚽", "❤", "✦")
    private val stickerTab = 5

    private val emoji = listOf(
        "😀 😃 😄 😁 😆 😅 😂 🤣 😊 😇 🙂 🙃 😉 😍 🥰 😘 😋 😛 😜 🤪 🤗 🤔 🤨 😐 😑 😶 🙄 😏 😴 😪 😎 🤓 😢 😭 😤 😡 🥺 😱 🥳 🤯",
        "🐶 🐱 🐭 🐹 🐰 🦊 🐻 🐼 🐨 🐯 🦁 🐮 🐷 🐸 🐵 🐔 🐧 🐦 🦆 🦉 🐺 🐴 🦄 🐝 🦋 🐢 🐍 🐙 🐬 🐳 🦈 🐘",
        "🍎 🍐 🍊 🍋 🍌 🍉 🍇 🍓 🍒 🍑 🥭 🍍 🥥 🥑 🍅 🌽 🥕 🍞 🧀 🍳 🥞 🍔 🍟 🍕 🌭 🌮 🍜 🍣 🍩 🍪 🍫 ☕",
        "⚽ 🏀 🏈 ⚾ 🎾 🏐 🏓 🏸 🥊 🎯 🎮 🎲 🎸 🎹 🎧 🎤 🎬 🎨 🚗 🚀 🏠 🌍",
        "❤ 🧡 💛 💚 💙 💜 🖤 🤍 💔 ✨ ⭐ 🔥 💯 ✅ ❌ ❗ ❓ 👍 👎 👏 🙏 💪 👋 🤝 🎉 🎁 💡 🌙 ⚡"
    )

    private val tabBar = LinearLayout(context)
    private val scroll = ScrollView(context)
    private val grid = GridLayout(context)
    private val bottomBar = LinearLayout(context)
    private val tabs = ArrayList<TextView>()
    private val backBtn = TextView(context)
    private val delBtn = TextView(context)

    private var selected = 0
    private var theme: KeyTheme = Themes.presets[0]

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    init {
        orientation = LinearLayout.VERTICAL
        tabBar.orientation = LinearLayout.HORIZONTAL
        bottomBar.orientation = LinearLayout.HORIZONTAL

        addView(tabBar, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(40)))
        scroll.addView(grid)
        addView(scroll, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))
        addView(bottomBar, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(44)))

        for ((i, label) in tabLabels.withIndex()) {
            val tv = TextView(context)
            tv.text = label
            tv.textSize = 20f
            tv.gravity = Gravity.CENTER
            tv.setOnClickListener { select(i) }
            tabs.add(tv)
            tabBar.addView(tv, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, 1f))
        }

        backBtn.text = "ABC"
        backBtn.textSize = 16f
        backBtn.gravity = Gravity.CENTER
        backBtn.setOnClickListener { listener?.onBack() }

        delBtn.text = "⌫"
        delBtn.textSize = 20f
        delBtn.gravity = Gravity.CENTER
        delBtn.setOnClickListener { listener?.onDelete() }

        val spacer = android.view.View(context)
        bottomBar.addView(backBtn, marginParams(1f))
        bottomBar.addView(spacer, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, 4f))
        bottomBar.addView(delBtn, marginParams(1f))
    }

    private fun marginParams(weight: Float): LinearLayout.LayoutParams {
        val lp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, weight)
        lp.setMargins(dp(4), dp(4), dp(4), dp(4))
        return lp
    }

    private fun pill(color: Int): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(color)
        g.cornerRadius = dp(8).toFloat()
        return g
    }

    fun applyTheme(t: KeyTheme, rowHeightPx: Float) {
        theme = t
        setBackgroundColor(t.boardBg)
        tabBar.layoutParams.height = (rowHeightPx * 0.8f).toInt()
        bottomBar.layoutParams.height = (rowHeightPx * 0.9f).toInt()
        tabBar.requestLayout()
        bottomBar.requestLayout()

        for (b in listOf(backBtn, delBtn)) {
            b.setTextColor(t.keyText)
            b.background = pill(t.specialBg)
        }
        select(selected)
    }

    fun refresh() = select(selected)

    private fun select(i: Int) {
        selected = i
        for ((idx, tv) in tabs.withIndex()) {
            tv.setTextColor(theme.keyText)
            tv.background = if (idx == i) pill(theme.specialBg) else null
        }
        fill()
        scroll.scrollTo(0, 0)
    }

    private fun fill() {
        grid.removeAllViews()

        val items: List<String>
        val cols: Int
        val size: Float
        if (selected == stickerTab) {
            items = prefs.stickers.split("\n").map { it.trim() }.filter { it.isNotEmpty() }
            cols = 2
            size = 16f
        } else {
            items = emoji[selected].split(" ")
            cols = 8
            size = 24f
        }
        grid.columnCount = cols

        if (items.isEmpty()) {
            val hint = TextView(context)
            hint.text = "No stickers yet. Add some in the Saimz Key app."
            hint.setTextColor(theme.keyText)
            hint.setPadding(dp(12), dp(12), dp(12), dp(12))
            grid.addView(hint)
            return
        }

        for (item in items) {
            val tv = TextView(context)
            tv.text = item
            tv.textSize = size
            tv.gravity = Gravity.CENTER
            tv.maxLines = 1
            tv.ellipsize = TextUtils.TruncateAt.END
            tv.setTextColor(theme.keyText)
            tv.setPadding(dp(2), dp(8), dp(2), dp(8))
            tv.setOnClickListener { listener?.onInsert(item) }

            val lp = GridLayout.LayoutParams(
                GridLayout.spec(GridLayout.UNDEFINED),
                GridLayout.spec(GridLayout.UNDEFINED, 1f)
            )
            lp.width = 0
            lp.height = LinearLayout.LayoutParams.WRAP_CONTENT
            grid.addView(tv, lp)
        }
    }
}
