package com.keysstudio.keyboard

import android.graphics.Color

class KeyTheme(
    val name: String,
    val boardBg: Int,
    val keyBg: Int,
    val specialBg: Int,
    val keyText: Int,
    val accent: Int,
    val border: Int
)

object Themes {

    /** themeIndex value that means "use the custom colors". */
    const val CUSTOM = 100

    val presets: List<KeyTheme> = listOf(
        KeyTheme(
            "Midnight",
            0xFF12141A.toInt(), 0xFF2B2F3A.toInt(), 0xFF1D2028.toInt(),
            0xFFEDEFF5.toInt(), 0xFF4C8DFF.toInt(), 0xFF3A3F4D.toInt()
        ),
        KeyTheme(
            "Cream",
            0xFFF3EBDD.toInt(), 0xFFFFFBF2.toInt(), 0xFFE2D6C0.toInt(),
            0xFF3B3226.toInt(), 0xFFD9822B.toInt(), 0xFFD5C7AB.toInt()
        ),
        KeyTheme(
            "Sakura",
            0xFFFFE4EC.toInt(), 0xFFFFFFFF.toInt(), 0xFFFFC7D8.toInt(),
            0xFF5A2A3C.toInt(), 0xFFFF5C8A.toInt(), 0xFFF5B5C8.toInt()
        ),
        KeyTheme(
            "Neon",
            0xFF0A0614.toInt(), 0xFF1A1030.toInt(), 0xFF120A24.toInt(),
            0xFF39FFD0.toInt(), 0xFFFF2BD6.toInt(), 0xFF7A3CFF.toInt()
        ),
        KeyTheme(
            "Forest",
            0xFF14241C.toInt(), 0xFF24402F.toInt(), 0xFF1B3125.toInt(),
            0xFFE4F2E7.toInt(), 0xFF7BD88F.toInt(), 0xFF35593F.toInt()
        ),
        KeyTheme(
            "Mono",
            0xFFFFFFFF.toInt(), 0xFFF1F1F1.toInt(), 0xFFDCDCDC.toInt(),
            0xFF111111.toInt(), 0xFF111111.toInt(), 0xFFC8C8C8.toInt()
        )
    )

    fun resolve(p: Prefs): KeyTheme {
        val i = p.themeIndex
        if (i in presets.indices) return presets[i]
        val key = p.customKeyBg
        return KeyTheme(
            "Custom",
            p.customBoardBg,
            key,
            shade(key, 0.82f),
            p.customKeyText,
            p.customKeyText,
            shade(key, 0.7f)
        )
    }

    fun shade(color: Int, factor: Float): Int {
        val r = (Color.red(color) * factor).toInt().coerceIn(0, 255)
        val g = (Color.green(color) * factor).toInt().coerceIn(0, 255)
        val b = (Color.blue(color) * factor).toInt().coerceIn(0, 255)
        return Color.argb(Color.alpha(color), r, g, b)
    }

    /** A readable text color for something drawn on top of [bg]. */
    fun onColor(bg: Int): Int {
        val lum = (0.299f * Color.red(bg) + 0.587f * Color.green(bg) + 0.114f * Color.blue(bg)) / 255f
        return if (lum > 0.6f) 0xFF111111.toInt() else 0xFFFFFFFF.toInt()
    }
}
