package com.keysstudio.keyboard

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.view.MotionEvent
import android.view.View

/**
 * Draws the keys itself, so themes, corner radius, gaps, borders and
 * one-handed mode are all just numbers it reads from [Prefs].
 */
class KeyboardView(context: Context) : View(context) {

    interface Listener {
        fun onKey(key: Key)
    }

    private class KeyRect(val key: Key, val draw: RectF, val hit: RectF)

    var listener: Listener? = null

    var rows: List<Row> = emptyList()
        set(value) {
            field = value
            pressed.clear()
            stopRepeat()
            dirty = true
            invalidate()
        }

    /** 0 = off, 1 = shift once, 2 = caps lock */
    var shiftState: Int = 0
        set(value) {
            field = value
            invalidate()
        }

    var baseRowHeightPx: Float = 0f
        private set

    private var theme: KeyTheme = Themes.presets[0]
    private var radiusPx = 0f
    private var gapPx = 0f
    private var borderPx = 0f
    private var fixedRows = 4
    private var oneHanded = 0
    private var showPopup = true

    private var boardLeft = 0f
    private var boardWidth = 0f
    private var lastRowH = 0f
    private var dirty = true

    private val keyRects = ArrayList<KeyRect>()
    private val pressed = HashMap<Int, Key>()

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER }

    private var repeatKey: Key? = null
    private val repeatRunnable = object : Runnable {
        override fun run() {
            val k = repeatKey ?: return
            listener?.onKey(k)
            postDelayed(this, 45)
        }
    }

    fun applyPrefs(p: Prefs) {
        val d = resources.displayMetrics.density
        theme = Themes.resolve(p)
        radiusPx = p.radiusDp * d
        gapPx = p.gapDp * d
        borderPx = p.borderDp * d
        baseRowHeightPx = 50f * d * p.heightPercent / 100f
        oneHanded = p.oneHanded
        showPopup = p.showPopup
        fixedRows = if (p.numberRow) 5 else 4
        stroke.strokeWidth = borderPx
        dirty = true
        requestLayout()
        invalidate()
    }

    /** Total height stays the same in every mode; rows stretch to fill it. */
    fun totalHeight(): Int = (fixedRows * baseRowHeightPx + gapPx).toInt()

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        setMeasuredDimension(MeasureSpec.getSize(widthMeasureSpec), totalHeight())
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        dirty = true
    }

    override fun onDetachedFromWindow() {
        stopRepeat()
        super.onDetachedFromWindow()
    }

    private fun buildRects() {
        dirty = false
        keyRects.clear()
        if (width == 0 || height == 0 || rows.isEmpty()) return

        boardWidth = if (oneHanded == 0) width.toFloat() else width * 0.82f
        boardLeft = if (oneHanded == 2) width - boardWidth else 0f

        val rowH = (height - gapPx) / rows.size
        lastRowH = rowH
        var y = gapPx / 2f
        for (row in rows) {
            var totalW = row.indent * 2f
            for (k in row.keys) totalW += k.weight
            val unit = (boardWidth - gapPx) / totalW
            var x = boardLeft + gapPx / 2f + row.indent * unit
            for (k in row.keys) {
                val kw = k.weight * unit
                val slot = RectF(x, y, x + kw, y + rowH)
                val draw = RectF(
                    x + gapPx / 2f,
                    y + gapPx / 2f,
                    x + kw - gapPx / 2f,
                    y + rowH - gapPx / 2f
                )
                keyRects.add(KeyRect(k, draw, slot))
                x += kw
            }
            y += rowH
        }
    }

    private fun labelFor(k: Key): String = when (k.type) {
        KeyType.SHIFT -> if (shiftState == 2) "⇪" else "⇧"
        KeyType.SPACE -> ""
        KeyType.CHAR ->
            if (shiftState != 0 && k.label.length == 1 && k.label[0].isLetter()) k.label.uppercase()
            else k.label
        else -> k.label
    }

    override fun onDraw(canvas: Canvas) {
        if (dirty) buildRects()
        canvas.drawColor(theme.boardBg)

        for (kr in keyRects) {
            val k = kr.key
            val isPressed = pressed.containsValue(k)
            val shiftActive = k.type == KeyType.SHIFT && shiftState != 0

            val bg = when {
                isPressed -> theme.accent
                k.type == KeyType.ENTER || shiftActive -> theme.accent
                k.type == KeyType.CHAR || k.type == KeyType.SPACE -> theme.keyBg
                else -> theme.specialBg
            }
            val fg = if (bg == theme.accent) Themes.onColor(theme.accent) else theme.keyText

            fill.color = bg
            canvas.drawRoundRect(kr.draw, radiusPx, radiusPx, fill)
            if (borderPx > 0f) {
                stroke.color = theme.border
                canvas.drawRoundRect(kr.draw, radiusPx, radiusPx, stroke)
            }

            val label = labelFor(k)
            if (label.isNotEmpty()) {
                text.color = fg
                text.textSize = if (label.length > 1) lastRowH * 0.27f else lastRowH * 0.40f
                val ty = kr.draw.centerY() - (text.descent() + text.ascent()) / 2f
                canvas.drawText(label, kr.draw.centerX(), ty, text)
            }
        }

        if (showPopup) drawPopups(canvas)
    }

    private fun drawPopups(canvas: Canvas) {
        for (kr in keyRects) {
            if (kr.key.type != KeyType.CHAR || !pressed.containsValue(kr.key)) continue
            val bw = kr.draw.width() * 1.35f
            val bh = kr.draw.height() * 1.25f
            val top = kr.draw.top - bh - gapPx
            if (top < 0f) continue
            val left = (kr.draw.centerX() - bw / 2f).coerceIn(0f, maxOf(0f, width - bw))
            val r = RectF(left, top, left + bw, top + bh)

            fill.color = theme.accent
            canvas.drawRoundRect(r, radiusPx * 1.3f, radiusPx * 1.3f, fill)

            text.color = Themes.onColor(theme.accent)
            text.textSize = kr.draw.height() * 0.62f
            val ty = r.centerY() - (text.descent() + text.ascent()) / 2f
            canvas.drawText(labelFor(kr.key), r.centerX(), ty, text)
        }
    }

    /** Nearest key to the touch point, so gaps and edges never swallow a tap. */
    private fun keyAt(x: Float, y: Float): KeyRect? {
        if (x < boardLeft || x > boardLeft + boardWidth) return null
        var best: KeyRect? = null
        var bestD = Float.MAX_VALUE
        for (kr in keyRects) {
            val dx = when {
                x < kr.hit.left -> kr.hit.left - x
                x > kr.hit.right -> x - kr.hit.right
                else -> 0f
            }
            val dy = when {
                y < kr.hit.top -> kr.hit.top - y
                y > kr.hit.bottom -> y - kr.hit.bottom
                else -> 0f
            }
            val d = dx * dx + dy * dy
            if (d < bestD) {
                bestD = d
                best = kr
            }
        }
        return best
    }

    private fun startRepeat(k: Key) {
        repeatKey = k
        postDelayed(repeatRunnable, 380)
    }

    private fun stopRepeat() {
        repeatKey = null
        removeCallbacks(repeatRunnable)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (dirty) buildRects()
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                val i = e.actionIndex
                val kr = keyAt(e.getX(i), e.getY(i))
                if (kr != null) {
                    pressed[e.getPointerId(i)] = kr.key
                    listener?.onKey(kr.key)
                    if (kr.key.type == KeyType.DELETE) startRepeat(kr.key)
                    invalidate()
                }
            }

            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP -> {
                val k = pressed.remove(e.getPointerId(e.actionIndex))
                if (k != null && k.type == KeyType.DELETE) stopRepeat()
                invalidate()
            }

            MotionEvent.ACTION_CANCEL -> {
                pressed.clear()
                stopRepeat()
                invalidate()
            }
        }
        return true
    }
}
