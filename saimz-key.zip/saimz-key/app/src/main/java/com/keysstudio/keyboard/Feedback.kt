package com.keysstudio.keyboard

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager

/**
 * Key sounds and haptics. The custom sounds are synthesized in code,
 * so the app needs no audio files.
 */
class Feedback(private val context: Context, private val prefs: Prefs) {

    private val audio = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private val tracks = HashMap<Int, AudioTrack>()

    @Suppress("DEPRECATION")
    private val vibrator: Vibrator? =
        if (Build.VERSION.SDK_INT >= 31) {
            (context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager)?.defaultVibrator
        } else {
            context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
        }

    fun play(type: KeyType) {
        if (prefs.hapticOn) buzz()
        playSound(type)
    }

    fun release() {
        for (t in tracks.values) {
            try {
                t.release()
            } catch (e: Exception) {
            }
        }
        tracks.clear()
    }

    // ---- haptics -------------------------------------------------------

    @Suppress("DEPRECATION")
    private fun buzz() {
        val v = vibrator ?: return
        if (!v.hasVibrator()) return
        val s = prefs.hapticStrength.coerceIn(0, 100)
        val ms = 8L + (s * 0.22f).toLong()
        try {
            if (Build.VERSION.SDK_INT >= 26) {
                val amp = (60 + s * 1.95f).toInt().coerceIn(1, 255)
                v.vibrate(VibrationEffect.createOneShot(ms, amp))
            } else {
                v.vibrate(ms)
            }
        } catch (e: Exception) {
        }
    }

    // ---- sound ---------------------------------------------------------

    private fun playSound(type: KeyType) {
        val sound = prefs.soundType
        val volume = prefs.soundVolume.coerceIn(0, 100) / 100f
        if (sound <= 0 || volume <= 0f) return

        if (sound == 1) {
            val fx = when (type) {
                KeyType.SPACE -> AudioManager.FX_KEYPRESS_SPACEBAR
                KeyType.DELETE -> AudioManager.FX_KEYPRESS_DELETE
                KeyType.ENTER -> AudioManager.FX_KEYPRESS_RETURN
                else -> AudioManager.FX_KEYPRESS_STANDARD
            }
            audio.playSoundEffect(fx, volume)
            return
        }

        try {
            val track = tracks.getOrPut(sound) { buildTrack(sound) }
            track.stop()
            track.reloadStaticData()
            track.setVolume(volume)
            track.play()
        } catch (e: Exception) {
        }
    }

    private fun buildTrack(sound: Int): AudioTrack {
        val data = when (sound) {
            2 -> gen(35, 1900.0, 1300.0, 0.25, 7.0)   // soft tick
            3 -> gen(90, 720.0, 230.0, 0.0, 5.5)      // pop
            4 -> gen(70, 380.0, 260.0, 0.7, 6.0)      // typewriter
            else -> gen(130, 420.0, 960.0, 0.0, 4.5)  // bubble
        }
        val track = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(RATE)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .build()
            )
            .setBufferSizeInBytes(data.size * 2)
            .setTransferMode(AudioTrack.MODE_STATIC)
            .build()
        track.write(data, 0, data.size)
        return track
    }

    private fun gen(ms: Int, fStart: Double, fEnd: Double, noiseMix: Double, decay: Double): ShortArray {
        val n = RATE * ms / 1000
        val out = ShortArray(n)
        val rnd = java.util.Random(7)
        var phase = 0.0
        for (i in 0 until n) {
            val t = i.toDouble() / n
            val f = fStart + (fEnd - fStart) * t
            phase += 2.0 * Math.PI * f / RATE
            val env = Math.exp(-decay * t)
            val tone = Math.sin(phase) * (1.0 - noiseMix)
            val noise = (rnd.nextDouble() * 2.0 - 1.0) * noiseMix
            out[i] = ((tone + noise) * env * 0.6 * Short.MAX_VALUE).toInt().toShort()
        }
        return out
    }

    companion object {
        private const val RATE = 22050

        val SOUND_NAMES = listOf("Off", "System click", "Soft tick", "Pop", "Typewriter", "Bubble")
    }
}
