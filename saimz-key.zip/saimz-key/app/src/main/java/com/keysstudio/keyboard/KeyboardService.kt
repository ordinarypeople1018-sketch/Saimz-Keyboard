package com.keysstudio.keyboard

import android.inputmethodservice.InputMethodService
import android.os.SystemClock
import android.text.InputType
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputConnection
import android.widget.FrameLayout

class KeyboardService : InputMethodService(), KeyboardView.Listener {

    private lateinit var prefs: Prefs
    private lateinit var feedback: Feedback
    private lateinit var keyboardView: KeyboardView
    private lateinit var emojiPanel: EmojiPanel

    private var mode = Mode.LETTERS
    private var shift = 0
    private var lastShiftTap = 0L

    override fun onCreate() {
        super.onCreate()
        prefs = Prefs(this)
        feedback = Feedback(this, prefs)
    }

    override fun onDestroy() {
        feedback.release()
        super.onDestroy()
    }

    override fun onEvaluateFullscreenMode(): Boolean = false

    override fun onCreateInputView(): View {
        val frame = FrameLayout(this)

        keyboardView = KeyboardView(this)
        keyboardView.listener = this

        emojiPanel = EmojiPanel(this, prefs)
        emojiPanel.listener = object : EmojiPanel.Listener {
            override fun onInsert(text: String) {
                feedback.play(KeyType.CHAR)
                currentInputConnection?.commitText(text, 1)
            }

            override fun onBack() {
                feedback.play(KeyType.LETTERS)
                showLetters()
            }

            override fun onDelete() {
                feedback.play(KeyType.DELETE)
                sendDownUpKeyEvents(KeyEvent.KEYCODE_DEL)
            }
        }

        frame.addView(
            keyboardView,
            FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT)
        )
        frame.addView(
            emojiPanel,
            FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT)
        )
        emojiPanel.visibility = View.GONE

        applyAll()
        return frame
    }

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        if (!::keyboardView.isInitialized) return

        val type = info?.inputType ?: 0
        val cls = type and InputType.TYPE_MASK_CLASS
        mode = if (cls == InputType.TYPE_CLASS_NUMBER || cls == InputType.TYPE_CLASS_PHONE) Mode.SYM1 else Mode.LETTERS
        shift = if ((type and InputType.TYPE_TEXT_FLAG_CAP_SENTENCES) != 0) 1 else 0

        showLetters()
    }

    /** Re-reads every setting, so changes made in the app show up right away. */
    private fun applyAll() {
        val theme = Themes.resolve(prefs)
        keyboardView.applyPrefs(prefs)
        keyboardView.rows = Layouts.rows(mode, prefs.numberRow)
        keyboardView.shiftState = shift

        emojiPanel.applyTheme(theme, keyboardView.baseRowHeightPx)
        val lp = emojiPanel.layoutParams
        lp.height = keyboardView.totalHeight()
        emojiPanel.layoutParams = lp
    }

    private fun showLetters() {
        applyAll()
        emojiPanel.visibility = View.GONE
        keyboardView.visibility = View.VISIBLE
    }

    private fun showEmoji() {
        applyAll()
        keyboardView.visibility = View.GONE
        emojiPanel.visibility = View.VISIBLE
    }

    private fun setMode(m: Mode) {
        mode = m
        keyboardView.rows = Layouts.rows(mode, prefs.numberRow)
    }

    private fun setShift(s: Int) {
        shift = s
        keyboardView.shiftState = s
    }

    override fun onKey(key: Key) {
        val ic = currentInputConnection ?: return
        feedback.play(key.type)

        when (key.type) {
            KeyType.CHAR -> {
                var out = key.output
                if (shift != 0 && out.length == 1 && out[0].isLetter()) out = out.uppercase()
                ic.commitText(out, 1)
                if (shift == 1) setShift(0)
            }

            KeyType.SPACE -> ic.commitText(" ", 1)

            KeyType.DELETE -> sendDownUpKeyEvents(KeyEvent.KEYCODE_DEL)

            KeyType.ENTER -> enter(ic)

            KeyType.SHIFT -> {
                val now = SystemClock.uptimeMillis()
                val next = when {
                    shift == 0 -> 1
                    shift == 1 && now - lastShiftTap < 350 -> 2
                    else -> 0
                }
                lastShiftTap = now
                setShift(next)
            }

            KeyType.SYMBOLS -> setMode(Mode.SYM1)

            KeyType.LETTERS -> setMode(Mode.LETTERS)

            KeyType.MORE_SYMBOLS -> setMode(if (mode == Mode.SYM1) Mode.SYM2 else Mode.SYM1)

            KeyType.EMOJI -> showEmoji()
        }
    }

    private fun enter(ic: InputConnection) {
        val ei = currentInputEditorInfo
        val action = (ei?.imeOptions ?: 0) and EditorInfo.IME_MASK_ACTION
        val noAction = ((ei?.imeOptions ?: 0) and EditorInfo.IME_FLAG_NO_ENTER_ACTION) != 0
        if (noAction || action == EditorInfo.IME_ACTION_NONE || action == EditorInfo.IME_ACTION_UNSPECIFIED) {
            sendKeyChar('\n')
        } else {
            ic.performEditorAction(action)
        }
    }
}
