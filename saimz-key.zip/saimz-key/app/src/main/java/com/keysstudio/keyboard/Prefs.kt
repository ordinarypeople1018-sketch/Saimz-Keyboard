package com.keysstudio.keyboard

import android.content.Context

class Prefs(context: Context) {

    private val sp = context.applicationContext
        .getSharedPreferences("keys_studio", Context.MODE_PRIVATE)

    var themeIndex: Int
        get() = sp.getInt("theme", 0)
        set(v) = sp.edit().putInt("theme", v).apply()

    var customBoardBg: Int
        get() = sp.getInt("custom_board", 0xFF202124.toInt())
        set(v) = sp.edit().putInt("custom_board", v).apply()

    var customKeyBg: Int
        get() = sp.getInt("custom_key", 0xFF3C4043.toInt())
        set(v) = sp.edit().putInt("custom_key", v).apply()

    var customKeyText: Int
        get() = sp.getInt("custom_text", 0xFF8AB4F8.toInt())
        set(v) = sp.edit().putInt("custom_text", v).apply()

    var radiusDp: Int
        get() = sp.getInt("radius", 8)
        set(v) = sp.edit().putInt("radius", v).apply()

    var gapDp: Int
        get() = sp.getInt("gap", 4)
        set(v) = sp.edit().putInt("gap", v).apply()

    var borderDp: Int
        get() = sp.getInt("border", 0)
        set(v) = sp.edit().putInt("border", v).apply()

    var heightPercent: Int
        get() = sp.getInt("height", 100)
        set(v) = sp.edit().putInt("height", v).apply()

    /** 0 = off, 1 = left hand, 2 = right hand */
    var oneHanded: Int
        get() = sp.getInt("one_handed", 0)
        set(v) = sp.edit().putInt("one_handed", v).apply()

    var numberRow: Boolean
        get() = sp.getBoolean("number_row", false)
        set(v) = sp.edit().putBoolean("number_row", v).apply()

    var showPopup: Boolean
        get() = sp.getBoolean("popup", true)
        set(v) = sp.edit().putBoolean("popup", v).apply()

    var soundType: Int
        get() = sp.getInt("sound_type", 2)
        set(v) = sp.edit().putInt("sound_type", v).apply()

    var soundVolume: Int
        get() = sp.getInt("sound_volume", 60)
        set(v) = sp.edit().putInt("sound_volume", v).apply()

    var hapticOn: Boolean
        get() = sp.getBoolean("haptic_on", true)
        set(v) = sp.edit().putBoolean("haptic_on", v).apply()

    var hapticStrength: Int
        get() = sp.getInt("haptic_strength", 50)
        set(v) = sp.edit().putInt("haptic_strength", v).apply()

    var stickers: String
        get() = sp.getString("stickers", DEFAULT_STICKERS) ?: DEFAULT_STICKERS
        set(v) = sp.edit().putString("stickers", v).apply()

    companion object {
        val DEFAULT_STICKERS: String = listOf(
            "¯\\_(ツ)_/¯",
            "(╯°□°)╯︵ ┻━┻",
            "┬─┬ノ( º _ ºノ)",
            "(づ｡◕‿‿◕｡)づ",
            "(•‿•)",
            "ಠ_ಠ",
            "(ノ◕ヮ◕)ノ*:･ﾟ✧",
            "(｡♥‿♥｡)"
        ).joinToString("\n")
    }
}
