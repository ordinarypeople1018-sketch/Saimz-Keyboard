package com.keysstudio.keyboard

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.provider.Settings
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView

class SettingsActivity : Activity() {

    private lateinit var prefs: Prefs
    private lateinit var feedback: Feedback
    private lateinit var preview: KeyboardView

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = Prefs(this)
        feedback = Feedback(this, prefs)

        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(16), dp(20), dp(16), dp(40))
        val scroll = ScrollView(this)
        scroll.addView(col)
        setContentView(scroll)

        val wrap = LinearLayout.LayoutParams.WRAP_CONTENT
        val match = LinearLayout.LayoutParams.MATCH_PARENT

        // ---- header and setup -------------------------------------------
        col.addView(title("Saimz Key"))
        col.addView(body("Style your keyboard below. Then turn it on in system settings and switch to it."))
        col.addView(button("1. Enable keyboard") {
            startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS))
        })
        col.addView(button("2. Switch to Saimz Key") {
            val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            imm.showInputMethodPicker()
        })

        // ---- live preview ---------------------------------------------------
        col.addView(section("Live preview (tap keys to test sound and haptics)"))
        preview = KeyboardView(this)
        preview.listener = object : KeyboardView.Listener {
            override fun onKey(key: Key) {
                feedback.play(key.type)
            }
        }
        col.addView(preview, LinearLayout.LayoutParams(match, wrap))
        refreshPreview()

        // ---- theme ------------------------------------------------------------
        col.addView(section("Theme"))
        val themeRow = LinearLayout(this)
        themeRow.orientation = LinearLayout.HORIZONTAL
        val names = Themes.presets.map { it.name } + "Custom"
        names.forEachIndexed { i, n ->
            val b = Button(this)
            b.text = n
            b.isAllCaps = false
            b.setOnClickListener {
                prefs.themeIndex = if (i < Themes.presets.size) i else Themes.CUSTOM
                refreshPreview()
            }
            themeRow.addView(b)
        }
        val themeScroll = HorizontalScrollView(this)
        themeScroll.addView(themeRow)
        col.addView(themeScroll)

        col.addView(body("Custom colors (hex like #1E88E5). Typing a valid color switches to the Custom theme."))
        col.addView(hexField("Board background", prefs.customBoardBg) { prefs.customBoardBg = it })
        col.addView(hexField("Key color", prefs.customKeyBg) { prefs.customKeyBg = it })
        col.addView(hexField("Key text and accent", prefs.customKeyText) { prefs.customKeyText = it })

        // ---- shape and size ---------------------------------------------------
        col.addView(section("Key shape and size"))
        col.addView(seek("Corner radius", 0, 24, prefs.radiusDp, " dp") { prefs.radiusDp = it; refreshPreview() })
        col.addView(seek("Key gap", 1, 10, prefs.gapDp, " dp") { prefs.gapDp = it; refreshPreview() })
        col.addView(seek("Border", 0, 3, prefs.borderDp, " dp") { prefs.borderDp = it; refreshPreview() })
        col.addView(seek("Keyboard height", 80, 140, prefs.heightPercent, "%") { prefs.heightPercent = it; refreshPreview() })

        // ---- layout ---------------------------------------------------------------
        col.addView(section("Layout"))
        col.addView(toggle("Number row on top", prefs.numberRow) { prefs.numberRow = it; refreshPreview() })
        col.addView(toggle("Key preview popup", prefs.showPopup) { prefs.showPopup = it; refreshPreview() })
        col.addView(body("One-handed mode"))
        col.addView(radios(listOf("Off", "Left hand", "Right hand"), prefs.oneHanded) {
            prefs.oneHanded = it
            refreshPreview()
        })

        // ---- sound ---------------------------------------------------------------------
        col.addView(section("Key sound"))
        col.addView(radios(Feedback.SOUND_NAMES, prefs.soundType) {
            prefs.soundType = it
            feedback.play(KeyType.CHAR)
        })
        col.addView(seek("Volume", 0, 100, prefs.soundVolume, "%") { prefs.soundVolume = it })
        col.addView(body("\"System click\" follows your phone's touch sounds setting."))

        // ---- haptics --------------------------------------------------------------------
        col.addView(section("Haptics"))
        col.addView(toggle("Vibrate on key press", prefs.hapticOn) { prefs.hapticOn = it })
        col.addView(seek("Strength", 0, 100, prefs.hapticStrength, "%") { prefs.hapticStrength = it })

        // ---- stickers -----------------------------------------------------------------------
        col.addView(section("Text stickers (one per line)"))
        val stickers = EditText(this)
        stickers.setText(prefs.stickers)
        stickers.minLines = 4
        stickers.gravity = Gravity.TOP or Gravity.START
        stickers.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
        stickers.addTextChangedListener(watcher { prefs.stickers = it })
        col.addView(stickers, LinearLayout.LayoutParams(match, wrap))

        // ---- test field ------------------------------------------------------------------------
        col.addView(section("Try it"))
        val test = EditText(this)
        test.hint = "Tap here to type with your keyboard"
        col.addView(test, LinearLayout.LayoutParams(match, wrap))
    }

    override fun onDestroy() {
        feedback.release()
        super.onDestroy()
    }

    private fun refreshPreview() {
        preview.applyPrefs(prefs)
        preview.rows = Layouts.rows(Mode.LETTERS, prefs.numberRow)
        preview.requestLayout()
    }

    // ---- small view builders -----------------------------------------------------------------------

    private fun title(t: String): TextView {
        val tv = TextView(this)
        tv.text = t
        tv.textSize = 26f
        tv.typeface = Typeface.DEFAULT_BOLD
        return tv
    }

    private fun section(t: String): TextView {
        val tv = TextView(this)
        tv.text = t
        tv.textSize = 17f
        tv.typeface = Typeface.DEFAULT_BOLD
        tv.setPadding(0, dp(24), 0, dp(6))
        return tv
    }

    private fun body(t: String): TextView {
        val tv = TextView(this)
        tv.text = t
        tv.textSize = 14f
        tv.setTextColor(Color.DKGRAY)
        tv.setPadding(0, dp(4), 0, dp(4))
        return tv
    }

    private fun button(t: String, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = t
        b.isAllCaps = false
        b.setOnClickListener { onClick() }
        return b
    }

    private fun toggle(label: String, checked: Boolean, onChange: (Boolean) -> Unit): Switch {
        val s = Switch(this)
        s.text = label
        s.isChecked = checked
        s.setPadding(0, dp(8), 0, dp(8))
        s.setOnCheckedChangeListener { _, c -> onChange(c) }
        return s
    }

    private fun seek(
        label: String,
        lo: Int,
        hi: Int,
        value: Int,
        suffix: String,
        onChange: (Int) -> Unit
    ): View {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(0, dp(8), 0, 0)

        val tv = TextView(this)
        tv.text = "$label: $value$suffix"

        val sb = SeekBar(this)
        sb.max = hi - lo
        sb.progress = (value - lo).coerceIn(0, hi - lo)
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                val v = lo + p
                tv.text = "$label: $v$suffix"
                if (fromUser) onChange(v)
            }

            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })

        box.addView(tv)
        box.addView(sb)
        return box
    }

    private fun radios(options: List<String>, selected: Int, onSelect: (Int) -> Unit): RadioGroup {
        val g = RadioGroup(this)
        options.forEachIndexed { i, name ->
            val r = RadioButton(this)
            r.id = View.generateViewId()
            r.text = name
            r.isChecked = (i == selected)
            r.setOnClickListener { onSelect(i) }
            g.addView(r)
        }
        return g
    }

    private fun hexField(label: String, initial: Int, onColor: (Int) -> Unit): View {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.HORIZONTAL
        box.gravity = Gravity.CENTER_VERTICAL

        val tv = TextView(this)
        tv.text = label
        box.addView(tv, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))

        val et = EditText(this)
        et.setText(String.format("#%06X", initial and 0xFFFFFF))
        et.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
        et.setSingleLine(true)
        et.addTextChangedListener(watcher { s ->
            if (s.length == 7 && s.startsWith("#")) {
                try {
                    onColor(Color.parseColor(s))
                    prefs.themeIndex = Themes.CUSTOM
                    refreshPreview()
                } catch (e: IllegalArgumentException) {
                }
            }
        })
        box.addView(et, LinearLayout.LayoutParams(dp(130), LinearLayout.LayoutParams.WRAP_CONTENT))
        return box
    }

    private fun watcher(onText: (String) -> Unit): TextWatcher = object : TextWatcher {
        override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
        override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
        override fun afterTextChanged(s: Editable?) {
            onText(s?.toString() ?: "")
        }
    }
}
