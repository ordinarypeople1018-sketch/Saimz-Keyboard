# Saimz Key

A standalone Android keyboard inspired by Samsung's Keys Cafe. Keys Cafe only restyles the
Samsung Keyboard (and needs Good Lock); this is its own keyboard, so it works on any Android 7.0+ phone.

## What it does

- **Themes and colors:** 6 presets plus custom hex colors, corner radius, key gap, border, keyboard height
- **Sounds and haptics:** 4 built-in synthesized key sounds (soft tick, pop, typewriter, bubble) plus system click, volume, vibration strength
- **Emoji and stickers:** emoji panel with 5 categories, and a stickers tab of text stickers you edit in the app
- **Layout options:** optional number row, key preview popup, one-handed mode (left or right)
- Symbols pages, shift and caps lock (double tap), hold-to-repeat delete, enter key follows the app's action

## Build the APK with GitHub Actions

1. Create a new GitHub repo and push this folder to the `main` branch.
2. Open the repo's **Actions** tab. The "Build APK" workflow runs on every push (or run it manually).
3. When it finishes, download the **saimz-key-debug-apk** artifact and unzip it.
4. Install `app-debug.apk` on your phone (allow installs from your browser or file manager).

## Turn it on

1. Open **Saimz Key** and tap **1. Enable keyboard**, then switch Saimz Key on.
2. Tap **2. Switch to Saimz Key** and pick it.
3. Style it in the app. Changes apply the next time the keyboard opens.

## Notes

- The stickers tab holds text stickers (kaomoji and similar). Image or GIF stickers would need extra work.
- Only English QWERTY is included. More layouts go in `Layouts.kt`.
- Debug builds are signed with the Android debug key. For the Play Store you would add a release signing config.
